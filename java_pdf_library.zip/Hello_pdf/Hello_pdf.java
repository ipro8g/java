import javax.swing.*;
import java.io.*; 
import java.awt.*;
import javax.swing.event.*;
import java.awt.event.*;
import com.packenius.library.xspdf.*;

public class Hello_pdf implements XS {

  public static void main(String[] args) throws IOException {

    String bus_name = "Firmware Electronics";
    String address = "Address";
    String province = "Province";
    String country = "Country";
    String phone = "Phone";
    String email = "Email";
    String date = "2/21/2022";
    String time = "8:26:54 PM";
    String inv_no = "18";
    String vendor = "Admin";

    XSPDF xsPDF = new XSPDF();
    xsPDF.setPageSize(80, 190);
    xsPDF.setAlignment(CENTERED);
    xsPDF.setTextParagraphIndentationSpaces(1);
    xsPDF.setFont(COURIER, BOLD);
    xsPDF.setFontSize(2.66);

    xsPDF.print(bus_name + "\n" + address + "\n" + province + " | " + country + "\n" + phone + " | " + email + "\nDate: " + date + " at: " + time + "\n" + "Invoice #" + inv_no + " | by: " + vendor + "\n----------------------------------------");

    xsPDF.createPdf("pdf/Example 011.pdf");
  }
}
