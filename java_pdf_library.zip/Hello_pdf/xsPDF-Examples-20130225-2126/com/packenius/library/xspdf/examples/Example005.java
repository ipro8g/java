package com.packenius.library.xspdf.examples;

import java.io.IOException;
import com.packenius.library.xspdf.XS;
import com.packenius.library.xspdf.XSPDF;

/**
 * Lorem ipsum...
 */
public class Example005 implements XS {
  /**
   * @param args Unused.
   * @throws IOException
   */
  public static void main(String[] args) throws IOException {
    XSPDF xsPDF = new XSPDF();
    xsPDF.print(LOREM_IPSUM);
    xsPDF.createPdf("pdf/Example 005.pdf");
  }
}
